﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Phase2_Submission.Model
{
    public partial class Account
    {
        public int AccountId { get; set; }
        public int AccNumber { get; set; }
        public int Amount { get; set; }
        public string Email { get; set; }
    }
}
